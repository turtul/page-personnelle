#!/usr/bin/bash
docker cp gnuplot3:/data/step4/ .
mv ./step4/ ./Graphiques/