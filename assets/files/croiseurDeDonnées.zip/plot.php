#!/usr/bin/php
<?php
	$fic_config = 'configGraphique';
	$dir_in = 'step2';
	$dir_out = 'step3';
	$dir_done = 'done';
	$nomdata = "data.csv";
	$numGraph = 0;
	echo "Création des dossiers $dir_in et $dir_out\n";
	if (!is_dir($dir_in)) {
	   mkdir($dir_in);
	}
	if (!is_dir($dir_out)) {
	   mkdir($dir_out);
	}
	if (!is_dir($dir_done)) {
		mkdir($dir_done);
	}
	echo "En attente de $dir_in/$fic_config\n";
	while (true) {
		if (is_file("$dir_in/$fic_config")) {
			echo "Trouvé $dir_in/$fic_config\n";
			$file = file("$dir_in/$fic_config");
			$nbElem = count($file);
			$titre = explode("=",$file[0]);
			$titre = $titre[1];
			$fin = explode("=",$file[2]);
			$fin = explode("-",$fin[1]);
			$fin = $fin[0] + 1;
			$deb = explode("=",$file[2]);
			$deb = explode("-",$deb[1]);
			$deb = $deb[0] - 1;
			$axeX = explode("=",$file[3]);
			$axeX = $axeX[1];
			$axeY = explode("=",$file[4]);
			$axeY = $axeY[1];
			$type = explode("=",$file[5]);
			$type = $type[1];
			$ville = array();
			for ($i=0; $i < $nbElem-6; $i++) {
				$ville[$i] = explode('=', trim($file[$i+6]));
				shell_exec("echo #{$ville[$i][1]} > '$dir_in/ville$i.csv'");
				shell_exec("egrep {$ville[$i][1]} < $dir_in/$nomdata >> '$dir_in/ville$i.csv'");
			}
			if($numGraph == 0){
				function nom2num($nom)
				{
					$nom = trim($nom);
					if("$nom" == "ville"){
						$num = 1;
					} else if("$nom" == "date"){
						$num = 2;
					} else if("$nom" == "temp min"){
						$num = 3;
					} else if("$nom" == "temp max"){
						$num = 4;
					} else if("$nom" == "temp moy"){
						$num = 5;
					} else if("$nom" == "quan plu"){
						$num = 6;
					} else if("$nom" == "quan sol"){
						$num = 7;
					} else if("$nom" == "dire ven"){
						$num = 8;
					} else {
						$num = 0;
					}
					return $num;
				}
			}
			$numX = nom2num($axeX);
			$numY = nom2num($axeY);
			$axeX = trim($axeX);
			$axeY = trim($axeY);
			$type = trim($type);
			$fic_config = trim($fic_config);
			$titre = trim($titre);
			file_put_contents("plot.p","reset\n");
			file_put_contents("plot.p","set title '$titre'\n",FILE_APPEND);
			file_put_contents("plot.p","set term png\n",FILE_APPEND);
			file_put_contents("plot.p","set xlabel '$axeX'\n",FILE_APPEND);
			file_put_contents("plot.p","set ylabel '$axeY'\n",FILE_APPEND);
			file_put_contents("plot.p","set output \"$dir_out/output$numGraph.png\"\n",FILE_APPEND);
			if($type == "boxes"){
				file_put_contents("plot.p","set style fill solid\nset boxwidth 0.5\n",FILE_APPEND);
			}
			for ($i=0; $i < $nbElem-6; $i++) {
				if($i == 0){
					file_put_contents("plot.p","plot '${dir_in}/ville$i.csv' using ${numX}:${numY} with ${type} t '{$ville[$i][1]}'",FILE_APPEND);
				} else {
					file_put_contents("plot.p"," , '${dir_in}/ville$i.csv' using ${numX}:${numY} with ${type} t '{$ville[$i][1]}'",FILE_APPEND);
				}
			}
			shell_exec("gnuplot plot.p");
			rename("$dir_in/$nomdata", "$dir_done/$nomdata");
			rename("$dir_in/$fic_config", "$dir_done/$fic_config");
			for ($i=0; $i < $nbElem-6; $i++) {
				rename("$dir_in/ville$i.csv","$dir_done/ville$i.csv");
			}
			$numGraph = $numGraph + 1;
			echo "Fin traitement\n";
		}
		sleep(5);
	}
?>