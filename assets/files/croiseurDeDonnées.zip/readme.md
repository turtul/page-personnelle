# Sujet 7 : Croiseur de Données

## Instalation
### Prérequis
- Docker
- L'image Gnuplot : bigpapoo/gnuplot

Cloner ce dépôt git sur votre ordinateur et suivez la documentation fournie.