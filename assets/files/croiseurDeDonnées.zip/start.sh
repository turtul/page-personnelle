#!/usr/bin/bash
echo Création du volume
docker volume create work

echo Mise en place des scripts dans le volume
docker container run -d --name gnuplot-tmp -v work:/data bigpapoo/gnuplot

docker cp fusion.php gnuplot-tmp:/data
docker cp plot.php gnuplot-tmp:/data
docker cp html.php gnuplot-tmp:/data

echo Fin de l\'initialisation
docker container stop gnuplot-tmp
docker container rm gnuplot-tmp

echo Lancement des conteneurs
docker container run -d --name gnuplot1 -w /data -v work:/data bigpapoo/gnuplot ./fusion.php
docker container run -d --name gnuplot2 -w /data -v work:/data bigpapoo/gnuplot ./plot.php
docker container run -d --name gnuplot3 -w /data -v work:/data bigpapoo/gnuplot ./html.php

echo Le volume à été créé, les scripts sont en attente des fichiers de configuration.
