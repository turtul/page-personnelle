#!/usr/bin/bash
docker cp genHtml gnuplot3:/data/step3/