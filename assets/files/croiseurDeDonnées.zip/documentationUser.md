## Utilisation :
- ajouter les 4 fichiers de données .csv dans le repertoire du projet : FichiersData/
- modifier le fichier configFic à l'aide d'un éditeur de texte pour y mettre les noms de fichiers ajoutés à droite du "="
- modifier le fichier configGraphique à l'aide d'un éditeur de texte ... /!\ ajouter les infos du config pour gnuplot
- ouvrir un terminal dans le dossier du projet et y lancer la commande ./start.sh
- lancer la commande ./put.php pour copier les fichiers dans le volume
- attendez la fin de l'execution de put.php pour lancer la commande ./get.sh pour récupérer les image de graphe générées par gnuplot grâce aux données fournis
- lancer la commande ./stop.sh pour arrêter le workflow

## Foncitonalités suplémentaires :
- il est tout à fait possible de modifier le fichier de config pour les fichier ou les graphique et de lancer ./put.php pour relancer le workflow avec de noueaux paramètres