#!/usr/bin/php
<?php
	$fic_config = 'configFic';
	$dir_in = 'step1';
	$dir_out = 'step2';
	$dir_done = 'done';
	echo "Création des dossiers $dir_in et $dir_out\n";
	if (!is_dir($dir_in)) {
	   mkdir($dir_in);
	}
	if (!is_dir($dir_out)) {
	   mkdir($dir_out);
	}
	if (!is_dir($dir_done)) {
		mkdir($dir_done);
	}
	echo "En attente de $dir_in/$fic_config\n";
	while (true) {
        if (!is_file("$dir_in/data.csv")){
            file_put_contents("$dir_in/data.csv","vILLE DATE TEMP_MIN TEMP_MAX TEMP_MOY QUAN_PLU QUAN_SOL DIRE_VEN FORC_VEN\n");
        }
		if (is_file("$dir_in/$fic_config")) {
			echo "Trouvé $dir_in/$fic_config\n";
			$ind = 0;
			$conf = file("$dir_in/$fic_config");
			foreach($conf as $line) {
				$parts = explode('=', trim($line));
				if($ind == 0){
					$nomFicPluie = $parts[1];
				}else if ($ind == 1){
					$nomFicTemp = $parts[1];
				} elseif ($ind == 2) {
					$nomFicSoleil = $parts[1];
				} else {
					$nomFicVent = $parts[1];
				}
				$ind++;
			}
			$str = file_get_contents("$dir_in/data.csv");
			$nblig = count(file("$dir_in/$nomFicPluie"));
			for($i = 0;$i < $nblig;$i++){	
				$lines = file("$dir_in/$nomFicTemp");
				$parts = explode(" ",trim($lines[$i+1]));	
				$str = $str . $parts[0] . " ". $parts[1] . " ". $parts[2] . " ". $parts[3] . " ". $parts[4] . " ";
	
				$lines = file("$dir_in/$nomFicPluie");
				$parts = explode(",",trim($lines[$i]));
				$str = $str . $parts[2] . " ";
				
				$lines = file("$dir_in/$nomFicSoleil");
				$parts = explode(",",trim($lines[$i]));
				$str = $str . $parts[2] . " ";
				
				$fileContent = file_get_contents("$dir_in/$nomFicVent");
				$tab = json_decode($fileContent, true);
				$str = $str . trim($tab["BREST"][$i]["direction"]) . " " . trim($tab["BREST"][$i]["force"]) . "\n";
			  
			  	file_put_contents("$dir_in/data.csv",$str);
			}
			echo "Fin traitement\n";
			rename("$dir_in/data.csv", "$dir_out/data.csv");
			rename("$dir_in/$fic_config", "$dir_done/$fic_config");
			rename("$dir_in/$nomFicTemp", "$dir_done/$nomFicTemp");
			rename("$dir_in/$nomFicPluie", "$dir_done/$nomFicPluie");
			rename("$dir_in/$nomFicSoleil", "$dir_done/$nomFicSoleil");
			rename("$dir_in/$nomFicVent", "$dir_done/$nomFicVent");
            rename("$dir_in/configGraphique", "$dir_out/configGraphique");
		}
		sleep(5);
	}
?>
