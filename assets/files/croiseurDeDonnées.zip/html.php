#!/usr/bin/php
<?php
    $dir_in = "step3";
    $dir_out = "step4";
    $dir_done = "done";
    $nomtraite = "traite";
    $numHtml = 0;
    $nbtraite = 0;
    echo "Création des dossiers $dir_in et $dir_out\n";
    if (!is_dir($dir_in)) {
        mkdir($dir_in);
    }
    if (!is_dir($dir_out)) {
        mkdir($dir_out);
    }
    if (!is_dir($dir_done)) {
		mkdir($dir_done);
	}
    echo "En attente de $dir_in/genHtml\n";
    echo "Utilisez ./get.sh pour récupérer les graphiques";
    while(true){
        if (is_file("$dir_in/genHtml")) {
            echo "Trouvé genHtml\n";
            rename("$dir_in/genHtml","$dir_done/genHtml");
            $nomfic = "Graphiques$numHtml.html";
            $files = preg_grep('/^([^.])/', scandir("$dir_in"));
            file_put_contents("$dir_in/$nomtraite",$nbtraite);
            file_put_contents($nomfic,"<html>\n    <h1>Voici vos graphiques :</h1>\n");
            foreach($files as $file) {
                file_put_contents($nomfic,"    <img src='$file'/>\n",FILE_APPEND);
                $nbtraite++;
            }
            file_put_contents($nomfic,"</html>",FILE_APPEND);
            $files = preg_grep('/^([^.])/', scandir("$dir_in"));
            file_put_contents("$dir_in/$nomtraite","Vous serez facturé pour $nbtraite graphiques");
            foreach($files as $file) {
                rename("$dir_in/$file","$dir_out/$file");
            }
            rename("$nomfic","$dir_out/$nomfic");
            $numHtml = $numHtml + 1;
            echo "Fin de traitement\n";
        }
        sleep(5);
    }
?>