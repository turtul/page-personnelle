#!/usr/bin/bash
docker container stop gnuplot1
docker container rm gnuplot1

docker container stop gnuplot2
docker container rm gnuplot2

docker container stop gnuplot3
docker container rm gnuplot3

docker volume rm work