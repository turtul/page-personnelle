# Sujet 7 : Croiseur de Données

## Etape 1 :
Le script` start.sh` crée le volume `work` et lance le conteneur `gnuplot-tmp` lié au volume `work`. Les script `fusion.php`, `plot.php` et `html.php` sont ensuite copiés dans `work:/data/` du conteneur `gnuplot-tmp`. Ce conteneur est ensuite supprimé mais le volume et son contenu restent accessibles. Ensuite ce script lance les conteneurs `gnuplot1` avec la commande `./fusion.php`, `gnuplot2` avec la commande `./plot.php` et `gnuplot3` avec la commande `./html.php`.

## Etape 2 :
Le script `put.php` permet d’envoyer les 4 fichiers de data déposés par l'utilisateur dans `/sae103-f7/FichiersData/` ainsi que les deux fichiers de configurations (modifiables par l’utilisateur) dans le dossier `/data/step1/` de `gnuplot1`. Cette action démarre le script `fusion.php`.

## Etape 3 :
Le script `fusion.php` prend les 4 fichiers de données trouvés dans le dossier `/data/step1/` à l’aide du fichier de configuration, qui lui donne leurs noms et les fusionne en un seul fichier, appelé `data.csv`. Il transfère ensuite les fichiers `configGraphique`, le fichier de configuration donnant les informations figurant sur le.s graphique.s à générer, et le fichier `data.csv` dans le dossier `/data/step2/`, correspondant au dossier entrant du prochain conteneur.

## Etape 4 :
Le script `plot.php` prend les fichiers de données`data.csv` ainsi que le fichier de configuration `configGraphique` dans le dossier `/data/step2/`. Il génère avec ces fichiers un fichier de script `plot.p`, contenant les paramètres destinés à gnuplot. Il récupère l’information de la ville dans le fichier de configuration et il génère autant de fichiers de data qu’il y a de ville.s, il nomme ces fichiers en fonction du nombre de ville.s (`ville[0-9]+¹.csv`). Il lance ensuite gnuplot, avec le script `plot.p` généré précédemment, ainsi que le.s fichier.s de données `ville[0-9]+.csv` pour générer les graphiques. Il les transfère ensuite dans `/data/step3/`, où ils seront récupérés par le script `html.php`, le sujet de l’étape 6.

## Etape 5 :
Le script `genHtml.sh` envoie le fichier `genHtml` dans le dossier `/data/step3/` de `gnuplot3` ce qui déclenche le script `html.php`.

## Etape 6 :
Le script `html.php` parcourt le dossier `/data/step3/`, recherchant les images et les intégrant dans un fichier html nommé de la manière que les fichiers de données des villes : `Graphiques[0-9]+.html`. Il va ensuite transférer les images ainsi que la page html les intégrant dans le dossier `/data/step4/`.

## Etape 7 :
Le script `get.sh` récupère le contenu du dossier du conteneur `gnuplot3` : `/data/step4/` et le copie dans le dossier de l'hôte : `/sae103-f7/graphique/`.

## Etape 8 :
Le script `stop.sh` va arrêter et supprimer l'ensemble des conteneurs utilisés pendant le workflow, pour s'assurer qu’ils ne posent aucun problème pour une future exécution de `start.sh`.

¹ `[0-9]+` cette expression régulière est utilisée juste pour améliorer la compréhension du moyen utilisé pour nommer les fichiers de données concernant les villes, aucune expression régulière n'est utilisée dans cette partie du script