#!/usr/bin/php
<?php
    $fic_config = 'configFic';
    $fic_config_graph = 'configGraphique';
    $conf = file("$fic_config");
    $ind = 0;
    foreach($conf as $line) {
        $parts = explode('=', trim($line));
        if($ind == 0){
            $nomFicPluie = $parts[1];
        }else if ($ind == 1){
            $nomFicTemp = $parts[1];
        } elseif ($ind == 2) {
            $nomFicSoleil = $parts[1];
        } else {
            $nomFicVent = $parts[1];
        }
        $ind++;
    }
    shell_exec("docker cp FichiersData/$nomFicPluie gnuplot1:/data/step1/");
    shell_exec("docker cp FichiersData/$nomFicTemp gnuplot1:/data/step1/");
    shell_exec("docker cp FichiersData/$nomFicSoleil gnuplot1:/data/step1/");
    shell_exec("docker cp FichiersData/$nomFicVent gnuplot1:/data/step1/");
    shell_exec("docker cp $fic_config gnuplot1:/data/step1/");
    shell_exec("docker cp $fic_config_graph gnuplot1:/data/step1/");
?>
